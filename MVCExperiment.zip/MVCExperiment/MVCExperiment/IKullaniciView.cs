﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVCExperiment
{
    public interface IKullaniciView
    {
        public void setController(KullaniciController controller);
        public void gridTemizle();
        public void gridKullaniciEkle(KullaniciModel user);
        public void gridKullaniciGuncelle(KullaniciModel user);
        public void gridKullaniciSil(KullaniciModel user);
        public string gridKullaniciID();
        public void gridKullaniciSec(KullaniciModel user);

        string textBoxAd { get; set; }
        string textBoxSoyad { get; set; }
        string textBoxID { get; set; }
        string textBoxBolum{ get; set; }

    }
}
