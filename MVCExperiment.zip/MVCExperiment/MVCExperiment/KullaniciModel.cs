﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVCExperiment
{
    public class KullaniciModel
    {

        public enum Cinsiyet
        {
            Erkek, Kiz
        }


        public String ID, ad, soyad, bolum;

        public KullaniciModel(string iD, string ad, string soyad, string bolum)
        {
            ID = iD;
            this.ad = ad;
            this.soyad = soyad;
            this.bolum = bolum;
        }

        public override bool Equals(object? obj)
        {
            return obj is KullaniciModel model &&
                   ID == model.ID;
        }
    }
}
