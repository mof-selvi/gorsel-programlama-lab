namespace MVCExperiment
{
    public partial class UsersView : Form, IKullaniciView
    {

        private KullaniciController _controller;
        private bool canModifyID = false;


        public UsersView()
        {
            InitializeComponent();
            gridTemizle();
        }


        public void gridTemizle()
        {
            this.dataGridView1.Rows.Clear();
        }


        public void setController(KullaniciController controller)
        {
            _controller = controller;
        }

        public void gridKullaniciEkle(KullaniciModel usr)
        {
            object[] input = new object[] { usr.ID, usr.ad, usr.soyad, usr.bolum };
            this.dataGridView1.Rows.Add(input);

        }

        public void gridKullaniciGuncelle(KullaniciModel usr)
        {
            DataGridViewRow rowToUpdate = null;

            foreach (DataGridViewRow row in this.dataGridView1.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString().Equals(usr.ID))
                {
                    rowToUpdate = row;
                }
            }

            if (rowToUpdate != null)
            {
                rowToUpdate.Cells[0].Value = usr.ID;
                rowToUpdate.Cells[1].Value = usr.ad;
                rowToUpdate.Cells[2].Value = usr.soyad;
                rowToUpdate.Cells[3].Value = usr.bolum;

            }
        }

        public void gridKullaniciSil(KullaniciModel usr)
        {

            DataGridViewRow rowToRemove = null;

            foreach (DataGridViewRow row in this.dataGridView1.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString().Equals(usr.ID))
                {
                    rowToRemove = row;
                }
            }

            if (rowToRemove != null)
            {
                this.dataGridView1.Rows.Remove(rowToRemove);
                this.dataGridView1.Focus();
            }
        }

        public string gridKullaniciID()
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
                return this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            else
                return "";
        }

        public void gridKullaniciSec(KullaniciModel usr)
        {
            foreach (DataGridViewRow row in this.dataGridView1.Rows)
            {

                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString().Equals(usr.ID))
                {
                    row.Selected = true;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this._controller.kullaniciEkle();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this._controller.kullaniciGuncelle();
        }

        public string textBoxAd
        {
            get { return this.txtFirstName.Text; }
            set { this.txtFirstName.Text = value; }
        }

        public string textBoxSoyad
        {
            get { return this.txtLastName.Text; }
            set { this.txtLastName.Text = value; }
        }

        public string textBoxID
        {
            get { return this.txtID.Text; }
            set { this.txtID.Text = value; }
        }


        public string textBoxBolum
        {
            get { return this.txtDepartment.Text; }
            set { this.txtDepartment.Text = value; }
        }


    }
}