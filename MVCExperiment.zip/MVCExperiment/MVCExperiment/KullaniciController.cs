﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVCExperiment
{
    public class KullaniciController
    {
       
        IKullaniciView _view;
        IList _kullanicilar;
        KullaniciModel _seciliUser;

        
        public KullaniciController(IKullaniciView view, IList users)
        {
            _view = view;
            _kullanicilar = users;
            view.setController(this);
        }

        public IList Users
        {
            get { return ArrayList.ReadOnly(_kullanicilar); }
        }

        private void guncelleView(KullaniciModel usr)
        {
            _view.textBoxAd = usr.ad;
            _view.textBoxSoyad = usr.soyad;
            _view.textBoxID = usr.ID;
            _view.textBoxBolum = usr.bolum;
            
        }

        private void guncelleModel(KullaniciModel usr)
        {
            usr.ad = _view.textBoxAd;
            usr.soyad = _view.textBoxSoyad;
            usr.ID = _view.textBoxID;
            usr.bolum = _view.textBoxBolum;
            
        }

        public void yukleView()
        {
            _view.gridTemizle();   
            foreach (KullaniciModel usr in _kullanicilar)
                _view.gridKullaniciEkle(usr);

            _view.gridKullaniciSec((KullaniciModel)_kullanicilar[0]);
        }

        public void seciliKullaniciDegisti(string selectedUserId)
        {
            foreach (KullaniciModel usr in this._kullanicilar)
            {
                if (usr.ID == selectedUserId)
                {
                    _seciliUser = usr;
                    guncelleView(usr);
                    _view.gridKullaniciSec(usr);
                    
                    break;
                }
            }
        }

        public void kullaniciEkle()
        {
            _seciliUser = new KullaniciModel(_view.textBoxID, _view.textBoxAd, _view.textBoxSoyad, _view.textBoxBolum);

            kaydet();
            
        }

        public void kullaniciGuncelle()
        {
            _seciliUser = new KullaniciModel(_view.textBoxID, _view.textBoxAd, _view.textBoxSoyad, _view.textBoxBolum);

            kaydet();

        }

        public void kullaniciSil()
        {
            string id = this._view.gridKullaniciID();
            KullaniciModel userToRemove = null;

            if (id != "")
            {
                foreach (KullaniciModel usr in this._kullanicilar)
                {
                    if (usr.ID == id)
                    {
                        userToRemove = usr;
                        break;
                    }
                }

                if (userToRemove != null)
                {
                    int newSelectedIndex = this._kullanicilar.IndexOf(userToRemove);
                    this._kullanicilar.Remove(userToRemove);
                    this._view.gridKullaniciSil(userToRemove);

                    if (newSelectedIndex > -1 && newSelectedIndex < _kullanicilar.Count)
                    {
                        this._view.gridKullaniciSec((KullaniciModel)_kullanicilar[newSelectedIndex]);
                    }
                }
            }
        }

        public void kaydet()
        {
            guncelleModel(_seciliUser);
            if (!this._kullanicilar.Contains(_seciliUser))
            {
                //Add new user
                this._kullanicilar.Add(_seciliUser);
                this._view.gridKullaniciEkle(_seciliUser);
            }
            else
            {
                //Update existing user
                this._view.gridKullaniciGuncelle(_seciliUser);
            }
            _view.gridKullaniciSec(_seciliUser);
            

        }
    }
}
