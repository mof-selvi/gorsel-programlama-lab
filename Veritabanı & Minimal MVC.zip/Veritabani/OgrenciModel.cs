﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veritabani
{
    public class OgrenciModel
    {


        public void Ekle(string form_ad, string form_soyad, string form_bolum)
        {
            string conn_str = "SERVER=localhost;UID=root;PWD=;DATABASE=ogrenciler";
            MySqlConnection conn = new MySqlConnection(conn_str);


            try
            {
                conn.Open();
                System.Diagnostics.Debug.WriteLine("DB connection succeeded!");
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
                System.Diagnostics.Debug.WriteLine(exc.Message);
            }

            MySqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO ogrenci (name,surname,department) VALUES (@name,@surname,@department);";
            cmd.Parameters.AddWithValue("@name", form_ad);
            cmd.Parameters.AddWithValue("@surname", form_soyad);
            cmd.Parameters.AddWithValue("@department", form_bolum);

            cmd.ExecuteNonQuery();



            conn.Close();
        }
    }


}
