

namespace Veritabani
{
    public partial class Form1 : Form
    {
        Controller controller;
        public Form1(Controller controller)
        {
            InitializeComponent();
            this.controller = controller;
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            this.controller.OgrenciEkle(text_ad.Text, text_soyad.Text, text_bolum.Text);
        }
    }
}