﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veritabani
{
    public class Controller
    {
        OgrenciModel ogrenciModel;
        public void SetOgrenciModel(OgrenciModel ogrenciModel)
        {
            this.ogrenciModel = ogrenciModel;
        }
        public void OgrenciEkle(string form_ad, string form_soyad, string form_bolum)
        {
            ogrenciModel.Ekle(form_ad, form_soyad, form_bolum);
        }
    }
}
